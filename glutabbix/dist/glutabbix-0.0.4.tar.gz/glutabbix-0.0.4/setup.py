from distutils.core import setup
setup(name='glutabbix',
      version='0.0.4',
      url='https://github.com/Azulinho/glutabbix',
      py_modules=['glutabbix'],
      )