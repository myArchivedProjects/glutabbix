from distutils.core import setup
setup(name='glutabbix',
      version='0.0.1',
      url='https://github.com/Azulinho/glutabbix',
      py_modules=['glutabbix'],
      )